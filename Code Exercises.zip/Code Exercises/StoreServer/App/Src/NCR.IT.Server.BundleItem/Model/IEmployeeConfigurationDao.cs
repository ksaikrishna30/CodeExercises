﻿using NCR.IT.Server.Model.BundleItem;
using System.Collections.Generic;

namespace NCR.IT.Server.BundleItem.Model
{
    public interface IEmployeeConfigurationDao
    {
        void SaveOrUpdate(IEmployeeConfiguration entity);
        IEnumerable<IEmployeeConfiguration> GetAll();
        IEmployeeConfiguration GetEmployeeConfigurationById(int Id);
        void Delete(IEmployeeConfiguration entity);
    }
}
