﻿//using Retalix.StoreServices.Model.Infrastructure.DataMovement;

//namespace NCR.IT.Server.BundleItem.Model.Configuration
//{
//    public interface IEmployeeConfigurationEntry : IMovable, INamedObject
//    {
//        int Id { get; set; }
//        string Name { get; set; }
//        string Email { get; set; }
//        string Designation { get; set; }
//    }
//}
