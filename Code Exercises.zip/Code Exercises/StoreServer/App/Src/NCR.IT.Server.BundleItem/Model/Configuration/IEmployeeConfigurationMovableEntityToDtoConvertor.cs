﻿//using Retalix.StoreServices.Model.Product.Versioning;

//namespace NCR.IT.Server.BundleItem.Model.Configuration
//{
//    public interface IEmployeeConfigurationMovableEntityToDtoConvertor : IMovableEntityToDtoConvertor
//    {
//    }
//}
