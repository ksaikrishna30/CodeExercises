﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Retalix.StoreServices.Model.Selling.RetailTransaction.RetailTransactionLog;
using Retalix.StoreServices.Model.Selling;
using Retalix.StoreServices.Model.Infrastructure.Audit;

namespace NCR.IT.Server.BundleItem.Model.Configuration
{
    public interface IEmployeeConfigurationLogWriter
    {
        void Write(IRetailTransactionLogDocumentWriter writer, IRetailTransaction retailTransaction);
    }
}
