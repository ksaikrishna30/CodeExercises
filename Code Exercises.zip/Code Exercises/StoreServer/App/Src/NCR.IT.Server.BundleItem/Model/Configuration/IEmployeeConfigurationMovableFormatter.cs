﻿//using Retalix.StoreServices.Model.Infrastructure.DataMovement;

//namespace NCR.IT.Server.BundleItem.Model.Configuration
//{
//    public interface IEmployeeConfigurationMovableFormatter : IMovableFormatter
//    {
//    }
//}
