﻿using NCR.IT.Server.Model.Exceptions;
using Retalix.StoreServices.Model.Infrastructure.Exceptions;

namespace NCR.IT.Server.BundleItem.Exceptions
{
    public class InvalidEmployeeConfigurationRequest : BusinessException
    {
        public InvalidEmployeeConfigurationRequest(string message)
            : base(message, ErrorCodes.BundleItemExceptionErrorCode)
        {
        }
    }
}
