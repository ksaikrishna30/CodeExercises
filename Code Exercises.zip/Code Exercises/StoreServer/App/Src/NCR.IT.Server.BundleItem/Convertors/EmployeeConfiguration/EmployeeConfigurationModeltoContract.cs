﻿using System;
using NCR.IT.Contracts.Generated.EmployeeConfiguration;
using NCR.IT.Server.Common.BusinessServices;
using NCR.IT.Server.Model.BundleItem;
using NCR.IT.Server.Model.RegistrationAttributes;
using Retalix.StoreServices.Model.Infrastructure.Service;

namespace NCR.IT.Server.BundleItem.Convertors.EmployeeConfiguration
{
    [RegisterAddition]
    public class EmployeeConfigurationModelToContract : IEmployeeConfigurationModelToContract
    {
        public EmployeeConfigurationType Convert(IEmployeeConfiguration employeeConfiguration)
        {
            return new EmployeeConfigurationType
            {
                Id = employeeConfiguration.Id,
                Name = employeeConfiguration != null ? employeeConfiguration.Name : string.Empty,
                Email = employeeConfiguration != null ? employeeConfiguration.Email : string.Empty,
                Designation = employeeConfiguration != null ? employeeConfiguration.Designation : string.Empty
            };
        }
    }
}
