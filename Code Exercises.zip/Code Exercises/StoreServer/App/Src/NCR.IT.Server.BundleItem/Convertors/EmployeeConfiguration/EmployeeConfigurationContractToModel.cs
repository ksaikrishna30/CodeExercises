﻿using System.Linq;
using System.Text;
using NCR.IT.Contracts.Generated.BundleItem;
using NCR.IT.Server.Model.BundleItem;
using NCR.IT.Server.Model.RegistrationAttributes;
using NCR.IT.Contracts.Generated.EmployeeConfiguration;

namespace NCR.IT.Server.BundleItem.Convertors
{
    [RegisterAddition]
    public class EmployeeConfigurationContractToModel : IEmployeeConfigurationContractToModel
    {
        private readonly IEmployeeConfigurationFactory _employeeConfigurationFactory;
        public EmployeeConfigurationContractToModel(IEmployeeConfigurationFactory bundleItemFactory)
        {
            _employeeConfigurationFactory = bundleItemFactory;

        }
        public IEmployeeConfiguration Convert(EmployeeConfigurationType employeeConfigurationType)
        {
            if (employeeConfigurationType != null && employeeConfigurationType != null)
            {
                var id = employeeConfigurationType.Id;
                var name = employeeConfigurationType.Name;
                var email = employeeConfigurationType.Email;
                var designation = employeeConfigurationType.Designation;
                return _employeeConfigurationFactory.CreateEmployeeConfiguration(id, name, email, designation);
            }
            return null;
        }
    }
}
