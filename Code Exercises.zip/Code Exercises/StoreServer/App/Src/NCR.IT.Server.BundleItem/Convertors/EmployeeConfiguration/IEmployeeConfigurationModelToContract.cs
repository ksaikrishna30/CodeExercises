﻿using NCR.IT.Contracts.Generated.EmployeeConfiguration;
using NCR.IT.Server.Model.BundleItem;
using Retalix.StoreServices.Model.Infrastructure.Service;

namespace NCR.IT.Server.BundleItem.Convertors.EmployeeConfiguration
{
    public interface IEmployeeConfigurationModelToContract
    {
        EmployeeConfigurationType Convert(IEmployeeConfiguration employeeConfiguration);
    }
}
