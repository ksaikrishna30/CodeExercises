using NCR.IT.Contracts.Generated.BundleItem;
using NCR.IT.Contracts.Generated.EmployeeConfiguration;
using NCR.IT.Server.Model.BundleItem;

namespace NCR.IT.Server.BundleItem.Convertors
{
    public interface IEmployeeConfigurationContractToModel
    {
        IEmployeeConfiguration Convert(EmployeeConfigurationType employeeConfigurationType);
    }
}