﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NCR.IT.Server.Model.BundleItem;
using ProtoBuf;

namespace NCR.IT.Server.BundleItem.BusinessComponents.EmployeeConfiguration
{
    [Serializable]
    [ProtoContract]
    public class EmployeeConfiguration : IEmployeeConfiguration 
    {
        private const string EntityNameKey = "EmployeeConfiguration";

        [ProtoMember(1)]
        public int Id { get; set; }
        [ProtoMember(2)]
        public string Name { get; set; }
        [ProtoMember(3)]
        public string Email { get; set; }
        [ProtoMember(4)]
        public string Designation { get; set; }
        [ProtoMember(5)]
        public string EntityName
        {
            get { return EntityNameKey; }
            set { }
        }
    }
}
