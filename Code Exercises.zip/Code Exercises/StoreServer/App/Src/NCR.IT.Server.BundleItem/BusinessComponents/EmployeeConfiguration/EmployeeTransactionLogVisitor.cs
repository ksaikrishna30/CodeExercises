﻿using System.Linq;
using Common.Logging;
using NCR.IT.Server.BundleItem.Model.Configuration;
using NCR.IT.Server.Common;
using NCR.IT.Server.Common.Model;
using NCR.IT.Server.Model.RegistrationAttributes;
using NCR.IT.Server.Model.TransactionLog;
using Retalix.StoreServices.Model.Infrastructure.Audit;
using Retalix.StoreServices.Model.Selling;

namespace NCR.IT.Server.BundleItem.BusinessComponents.EmployeeConfiguration
{
    [RegisterAddition]
    public class EmployeeConfigurationLogVisitor : TransactionLogVisitorBase
    {
        private readonly IAuditLogDao _auditLogDao;
        private readonly IEmployeeConfigurationLogWriter _employeeConfigurationLogWriter;
        private static readonly ILog Logger = LogManager.GetLogger(typeof(EmployeeConfigurationLogVisitor));

        public EmployeeConfigurationLogVisitor(IAuditLogDao auditLogDao, IEmployeeConfigurationLogWriter employeeConfigurationLogWriter)
        {
            _auditLogDao = auditLogDao;
            _employeeConfigurationLogWriter = employeeConfigurationLogWriter;
        }

        public override void Visit(IRetailTransactionLogExtendedVisitor extendedVisitor)
        {
            Logger.Debug("EmployeeConfigurationTLogVisitor::Visit");
            var retailTransaction = extendedVisitor.RetailTransaction;
            var emplopyeeConfigurationAuditLogs = _auditLogDao.GetAll();

            if (emplopyeeConfigurationAuditLogs != null && emplopyeeConfigurationAuditLogs.Any())
            {
                Logger.Debug("EmployeeConfigurationTLogVisitor::Visit found employee configuration audit logs - related nodes will be added to Tlog");
                _employeeConfigurationLogWriter.Write(extendedVisitor.Writer, retailTransaction);
            }
        }
    }
}