﻿using NCR.IT.Server.Model.BundleItem;
using NCR.IT.Server.Model.RegistrationAttributes;

namespace NCR.IT.Server.BundleItem.BusinessComponents
{
    [RegisterAddition]
    public class EmployeeConfigurationFactory : IEmployeeConfigurationFactory
    {
        public IEmployeeConfiguration CreateEmployeeConfiguration(int Id, string Name, string Email, string Designation)
        {
            return new EmployeeConfiguration.EmployeeConfiguration
            {
                Id = Id,
                Name = Name,
                Email = Email,
                Designation = Designation
            };
        }
        
    }
}
