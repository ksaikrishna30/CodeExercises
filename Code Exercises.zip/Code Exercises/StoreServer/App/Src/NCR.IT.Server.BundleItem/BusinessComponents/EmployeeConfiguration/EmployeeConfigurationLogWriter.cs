﻿using System;
using System.Collections.Generic;
using System.Xml;
using Common.Logging;
using Retalix.Contract.Schemas.Schema.ARTS.PosLog_V6.Objects;
using Retalix.Contract.Schemas.Schema.ARTS.PosLog_V6.Objects.SchemaObjects;
using Retalix.Contract.Schemas.Schema.ARTS.PosLog_V6.Objects.SpecialImplementation;
using Retalix.Contracts.Extensions;
using NCR.IT.Server.BundleItem.Model;
using NCR.IT.Server.Common;
using NCR.IT.Server.Model.RegistrationAttributes;
using Retalix.StoreServices.Model.Infrastructure.Audit;
using Retalix.StoreServices.Model.Selling;
using Retalix.StoreServices.Model.Selling.CustomerOrder.Line.Audit;
using Retalix.StoreServices.Model.Selling.RetailTransaction.RetailTransactionLog;
using NCR.IT.Server.BundleItem.Model.Configuration;
using Retalix.StoreServices.Model.Infrastructure.Globalization;

namespace NCR.IT.Server.BundleItem.BusinessComponents.EmployeeConfiguration
{
    [RegisterAddition]
    public class EmployeeConfigurationLogWriter : IEmployeeConfigurationLogWriter
    {
        private static readonly ILog Logger = LogManager.GetLogger(typeof(EmployeeConfigurationLogWriter));

        private readonly R10Extension _r10Extension = new R10Extension();

        public void Write(IRetailTransactionLogDocumentWriter writer, IRetailTransaction retailTransaction)
        {
            Logger.Debug("EmployeeConfigurationLogWriter:Write");
            
            var artsTransaction = (TransactionDomainSpecific)writer.ObjectContent;
            var retailTransactionLog = artsTransaction.GetMainRetailTransaction();

            var startTime = retailTransaction.StartTime;
            var endTime = retailTransaction.EndTime;

            var getTransactionTime = GetTransactionTime(startTime, endTime);

            retailTransactionLog.Any = new List<XmlElement> { CreateTimeSpanNode(getTransactionTime) };

            writer.UpdateArtsTransaction(artsTransaction); 
        }

        private TimeSpan GetTransactionTime(AbsoluteDateTime startTime, AbsoluteDateTime endTime)
        {
            return endTime - startTime;
        }

        private XmlElement CreateTimeSpanNode(TimeSpan transactionTime)
        {
            var transactionTimeNode = _r10Extension.CreateXmlElement("TransactionTime");
            transactionTimeNode.InnerText = transactionTime.ToString();
            return transactionTimeNode;
        }
    }
}

