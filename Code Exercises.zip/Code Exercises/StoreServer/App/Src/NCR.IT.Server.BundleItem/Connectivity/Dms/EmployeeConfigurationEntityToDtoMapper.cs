﻿//using System;
//using System.Linq;
//using NCR.IT.Server.Model.RegistrationAttributes;
//using Retalix.StoreServices.Model.Infrastructure.DataMovement;
//using Retalix.StoreServices.Model.Infrastructure.DataMovement.Versioning;
//using Retalix.StoreServices.Model.Infrastructure.UnitOfWork;
//using Retalix.StoreServices.Model.Product.Versioning;
//using NCR.IT.Server.BundleItem.Model.Configuration;

//namespace NCR.IT.Server.BundleItem.Connectivity.Dms
//{
//    [RegisterAddition]
//    public class EmployeeConfigurationEntityToDtoMapper : IEmployeeConfigurationEntityToDtoMapper
//    {
//        private readonly IEmployeeConfigurationMovableEntityToDtoConvertor _dtoConvertor;
//        private readonly IDtoVersionsConvertor _dtoVersionsConvertor;

//        public EmployeeConfigurationEntityToDtoMapper(IEmployeeConfigurationMovableEntityToDtoConvertor dtoConvertor, IDtoVersionsConvertor dtoVersionsConvertor)
//        {
//            _dtoConvertor = dtoConvertor;
//            _dtoVersionsConvertor = dtoVersionsConvertor;
//        }

//        public DtosForVersions[] Map(IMovable[] movables, MappingMetadata mappingMetadata, DataChangeType changeType)
//        {
//            var dtos = _dtoConvertor.MapToDto(movables, changeType);
//            return _dtoVersionsConvertor.Map(dtos, mappingMetadata, changeType);
//        }

//        public IMovable[] MapBack(INamedObject[] srcDtos, MappingMetadata mappingMetadata, DataChangeType changeType)
//        {
//            var dtos = _dtoVersionsConvertor.MapBack(srcDtos, mappingMetadata, changeType);
//            return _dtoConvertor.MapBackFromDto(dtos, changeType);
//        }

//        public string[] GetEntityNamesForVersion(string entityName, MappingMetadata mappingMetadata, DataChangeType changeType)
//        {
//            return _dtoVersionsConvertor.GetEntityNamesForVersion(entityName, mappingMetadata, changeType);
//        }

//        public Type GetNamedObjectType(string entityName, MappingMetadata mappingMetadata)
//        {
//            if (mappingMetadata.TargetNodesVersion.First() == mappingMetadata.SourceNodeVersion)
//                return _dtoConvertor.DtoType();

//            var objectType = _dtoVersionsConvertor.GetNamedObjectType(entityName, mappingMetadata) ?? _dtoConvertor.DtoType();

//            return objectType;
//        }
//    }
//}
