﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using NCR.IT.Server.Model.RegistrationAttributes;
//using Retalix.StoreServices.Model.Infrastructure.DataMovement;
//using Retalix.StoreServices.Model.Infrastructure.UnitOfWork;
//using NCR.IT.Server.BundleItem.Model.Configuration;
//using NCR.IT.Server.BundleItem.BusinessComponents.EmployeeConfiguration;

//namespace NCR.IT.Server.BundleItem.Connectivity.Dms
//{
//    [RegisterAddition]
//    public class EmployeeConfigurationMovableEntityToDtoConvertor : IEmployeeConfigurationMovableEntityToDtoConvertor
//    {
//        public IMovable[] MapBackFromDto(IEnumerable<INamedObject> dtos, DataChangeType changeType)
//        {
//            if (dtos == null)
//                return Enumerable.Empty<IMovable>() as IMovable[];

//            return dtos.Cast<EmployeeConfiguration>().Select(ToMovable).ToArray();
//        }

//        public INamedObject[] MapToDto(IEnumerable<IMovable> movables, DataChangeType changeType)
//        {
//            if (movables == null)
//                return Enumerable.Empty<INamedObject>() as INamedObject[];

//            return movables.Select(ToDto).ToArray();
//        }

//        public Type DtoType()
//        {
//            return typeof(EmployeeConfigurationEntry);
//        }

//        protected IMovable ToMovable(EmployeeConfigurationEntry dto)
//        {
//            return dto;
//        }

//        protected EmployeeonfigurationEntry ToDto(IMovable movable)
//        {
//            var dto = movable as EmployeeConfigurationEntry;
//            return dto;
//        }
//    }
//}
