﻿//using NCR.IT.Server.Common;
//using NCR.IT.Server.Model.RegistrationAttributes;
//using Retalix.StoreServices.Model.Infrastructure.DataMovement;
//using Retalix.StoreServices.Model.Infrastructure.DataMovement.Versioning;
//using NCR.IT.Server.BundleItem.Model.Configuration;

//namespace NCR.IT.Server.BundleItem.Connectivity.Dms
//{
//    [RegisterAddition(Id = "EmployeeConfigurationEntry", ImplInterfaceType = typeof(IMovableServicesResolver))]
//    public class EmployeeConfigurationMovableResolver : ICompatibilityMovableServicesResolver
//    {
//        private readonly IEmployeeConfigurationMovableDao _movableDao;
//        private readonly IEmployeeConfigurationEntityToDtoMapper _entityToDtoMapper;
//        private readonly IEmployeeConfigurationMovableFormatter _movableFormatter;

//        public EmployeeConfigurationMovableResolver(IEmployeeConfigurationMovableDao movableDao, IEmployeeConfigurationEntityToDtoMapper entityToDtoMapper,
//            IEmployeeConfigurationMovableFormatter movableFormatter)
//        {
//            _movableDao = movableDao;
//            _entityToDtoMapper = entityToDtoMapper;
//            _movableFormatter = movableFormatter;
//        }

//        public IMovableFormatter Formatter
//        {
//            get { return _movableFormatter; }
//        }
//        public IMovableDao MovableDao
//        {
//            get { return _movableDao; }
//        }

//        public IEntityToDtoMapper EntityToDtoMapper
//        {
//            get { return _entityToDtoMapper; }
//        }
//        public string ComponentName
//        {
//            get { return Constants.Movable.ComponentName; }
//        }

//    }
//}
