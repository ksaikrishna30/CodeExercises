﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using Common.Logging;
//using NHibernate;
//using NHibernate.Linq;
//using Retalix.StoreServices.Model.Infrastructure.DataAccess;
//using Retalix.StoreServices.Model.Infrastructure.DataMovement;
//using Retalix.StoreServices.Model.Infrastructure.DataMovement.DeleteAllProviders;
//using NCR.IT.Server.Model.RegistrationAttributes;
//using NCR.IT.Server.BundleItem.Model.Configuration;

//namespace NCR.IT.Server.BundleItem.Connectivity.Dms
//{
//    [RegisterAddition]
//    public class EmployeeConfigurationMovableDao : IEmployeeConfigurationMovableDao
//    {
//        private readonly ILog _logger = LogManager.GetLogger(typeof(EmployeeConfigurationMovableDao));

//        private readonly ISessionProvider _sessionProvider;


//        private ISession Session
//        {
//            get
//            {
//                return _sessionProvider.GetDefaultSession<ISession>();
//            }
//        }

//        public EmployeeConfigurationMovableDao(ISessionProvider sessionProvider)
//        {
//            _sessionProvider = sessionProvider;
//        }


//        public void Add(IEnumerable<IMovable> movables)
//        {
//            _logger.Info("EmployeeConfigurationMovableDao.Add : entered");
//            if (movables == null)
//            {
//                return;
//            }

//            movables.Cast<IEmployeeConfigurationEntry>().ForEach(SaveOrUpdate);
//        }

//        public void Update(IEnumerable<IMovable> movables)
//        {
//            _logger.Info("RetailerMovableDao.Update : entered");
//            if (movables == null)
//            {
//                return;
//            }

//            movables.Cast<IEmployeeConfigurationEntry>().ForEach(SaveOrUpdate);
//        }

//        public void Delete(IEnumerable<IMovable> movables)
//        {
//            try
//            {
//                if (movables == null)
//                    return;

//                _logger.Info("RetailerMovableDao.Delete : entered");
//                movables.ForEach(x => Session.Delete(x as IEmployeeConfigurationEntry));

//            }
//            catch (Exception e)
//            {
//                _logger.Error("RetailerMovableDao.Delete", e);
//                throw;
//            }        
//        }

//        public IEnumerable<IMovable> GetAll()
//        {
//            return Session.QueryOver<IEmployeeConfigurationEntry>().List();
//        }

//        public IEnumerable<IMovable> GetAll(IMovable startingPosition)
//        {
//            return GetAll();
//        }

//        public void DeleteAll(ITruncateHelperDao truncateHelperDao)
//        {
//            _logger.Info("EmployeeConfigurationMovableDao Truncating Employee Configuration table");
//            foreach (var table in GetTableNamesInDependencyOrder())
//                truncateHelperDao.TruncateTable(table);
//        }

//        public IList<string> GetTableNamesInDependencyOrder()
//        {
//            return new[] { "ITAM_EmployeeConfiguration" };
//        }

//        private void SaveOrUpdate(IEmployeeConfigurationEntry entity)
//        {
//            _logger.Info("EmployeeConfigurationMovableDao.SaveOrUpdate : entered");

//            try
//            {
//                Session.SaveOrUpdate(entity);
//            }
//            catch (Exception e)
//            {
//                _logger.Error("EmployeeConfigurationMovableDao.SaveOrUpdate", e);
//                throw;
//            }
//        }
//    }
//}
