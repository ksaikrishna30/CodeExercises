﻿//using System.Collections.Generic;
//using System.Linq;
//using System.Xml;
//using NCR.IT.Server.Common;
//using NCR.IT.Server.Model.RegistrationAttributes;
//using Retalix.StoreServices.Model.Infrastructure.DataMovement;
//using NCR.IT.Server.BundleItem.Model.Configuration;
//using NCR.IT.Server.BundleItem.BusinessComponents.EmployeeConfiguration;

//namespace NCR.IT.Server.BundleItem.Connectivity.Dms
//{
//    [RegisterAddition]
//    public class EmployeeConfigurationMovableFormatter : IEmployeeConfigurationMovableFormatter
//    {
//        public IEnumerable<XmlDocument> Serialize(IEnumerable<IMovable> movables)
//        {
//            return movables.Select(movable => movable.ToXmlDocument());
//        }

//        public IEnumerable<IMovable> Deserialize(IEnumerable<XmlDocument> contracts)
//        {
//            return contracts.Select(contract => contract.InnerXml.Deserialize<EmployeeConfiguration>()).ToList();
//        }
//    }
//}
