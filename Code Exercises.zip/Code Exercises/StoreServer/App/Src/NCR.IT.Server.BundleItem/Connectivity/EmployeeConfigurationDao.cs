﻿using Common.Logging;
using NCR.IT.Server.BundleItem.Model;
using NCR.IT.Server.BundleItem.Exceptions;
using NCR.IT.Server.Model.BundleItem;
using NCR.IT.Server.Model.RegistrationAttributes;
using NHibernate;
using NHibernate.Criterion;
using NHibernate.Linq;
using Retalix.StoreServices.Model.Infrastructure.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NCR.IT.Server.BundleItem.BusinessComponents.EmployeeConfiguration;

namespace NCR.IT.Server.BundleItem.Connectivity
{
    [RegisterAddition]
    public class EmployeeConfigurationDao : IEmployeeConfigurationDao
    {
        private readonly ISessionProvider _sessionProvider;

        private ISession Session
        {
            get { return _sessionProvider.GetDefaultSession<ISession>(); }
        }

        private static readonly ILog Log = LogManager.GetCurrentClassLogger();

        public EmployeeConfigurationDao(ISessionProvider sessionProvider)
        {
            _sessionProvider = sessionProvider;
        }

        public void SaveOrUpdate(IEmployeeConfiguration entity)
        {
            Log.Info(message => message("EmployeeConfigurationDao.SaveOrUpdate : entered"));

            try
            {
                IEmployeeConfiguration existingEmployee;

                if (entity.Id > 0)
                    existingEmployee = GetEmployeeConfigurationById(entity.Id);

                else
                    existingEmployee = new EmployeeConfiguration();

                if (existingEmployee != null)
                {
                    existingEmployee.Name = entity.Name;
                    existingEmployee.Email = entity.Email;
                    existingEmployee.Designation = entity.Designation;
                }
                else
                    existingEmployee = entity;

                Session.SaveOrUpdate(existingEmployee);
            }
            catch (Exception e)
            {
                Log.Error("EmployeeConfigurationDao.SaveOrUpdate", e);
                throw e;
            }
        }

        public IEmployeeConfiguration GetEmployeeConfigurationById(int id)
        {
            Log.Info(message => message("EmployeeConfigurationDao.GetEmployeeConfigurationById : entered"));
            var criteria = Session.CreateCriteria(typeof(IEmployeeConfiguration))
                .Add(Restrictions.Eq("Id", id));
            var result = criteria.List<IEmployeeConfiguration>();
            if (result.Count > 0)
            {
                return result.FirstOrDefault();
            }
            else
            {
                throw new InvalidEmployeeConfigurationRequest("Employee Configuration Not Found. Please check Input");
            }
        }

        public IEnumerable<IEmployeeConfiguration> GetAll()
        {
            Log.Info(message => message("EmployeeConfigurationDao.GetAll : entered"));

            List<IEmployeeConfiguration> records = Session.Query<IEmployeeConfiguration>().ToList();
            return records;
        }

        public void Delete(IEmployeeConfiguration entity)
        {
            Log.Info(message => message("EmployeeConfigurationDao.Delete : entered"));

            try
            {
                Session.Delete(entity);
            }
            catch (Exception e)
            {
                Log.Error("EmployeeConfigurationDao.Delete", e);
                throw e;
            }
        }
    }
}
