﻿using System;
using System.Collections.Generic;
using System.Linq;
using Common.Logging;
using NHibernate.Linq;
using Retalix.Contracts.Generated.Common;
using NCR.IT.Contracts.Generated.BundleItem;
using NCR.IT.Server.BundleItem.Convertors;
using NCR.IT.Server.BundleItem.Exceptions;
using NCR.IT.Server.BundleItem.Model;
using NCR.IT.Server.Common;
using NCR.IT.Server.Model.BundleItem;
using Retalix.DPOS.SystemIntegrity;
using Retalix.StoreServices.Model.Infrastructure.Globalization;
using Retalix.StoreServices.Model.Infrastructure.Legacy.Bulk;
using Retalix.StoreServices.Model.Organization.BusinessUnit;
using Retalix.StoreServices.Model.Price;
using Retalix.StoreServices.Model.Infrastructure.Exceptions;
using NCR.IT.Server.Model.RegistrationAttributes;
using NCR.IT.Server.Model.Infrastructure.Servers;
using NCR.IT.Contracts.Generated.EmployeeConfiguration;

namespace NCR.IT.Server.BundleItem.BusinessServices
{
    [RegisterService]
    public class EmployeeConfigurationMaintainenceService : BusinessServiceBase<EmployeeConfigurationMaintainenceRequest, EmployeeConfigurationMaintainenceResponse>
    {
        private static readonly ILog Logger = LogManager.GetLogger(typeof(EmployeeConfigurationMaintainenceService));

        private readonly IEmployeeConfigurationDao _employeeConfigurationDao;
        private readonly IEmployeeConfigurationContractToModel _employeeConfigurationContractToModel;

        public EmployeeConfigurationMaintainenceService(IEmployeeConfigurationDao employeeConfigurationDao, IEmployeeConfigurationContractToModel employeeConfigurationContractToModel)//, IBulkPersisterProvider bulkPersisterProvider, IServerTypeProvider serverTypeProvider, IPriceList priceList, IEmployeeDao employeeDao, IBusinessUnitDao businessUnitDao, IPriceDao priceDao, IStoreRangeDao storeRangeDao)
        {
            _employeeConfigurationDao = employeeConfigurationDao;
            _employeeConfigurationContractToModel = employeeConfigurationContractToModel;
        }

        protected override void InternalExecute()
        {
            if (Request == null || Request.EmployeeConfigurationType == null) return;
            Logger.Debug("EmployeeMaintainenceService: EmployeeMaintainenceService Starting");
            foreach(var employeeConfigurationType in Request.EmployeeConfigurationType)
            {
                ExecuteEmployeeConfiguration(employeeConfigurationType);
            }
            Logger.Debug("EmployeeMaintainenceService: EmployeeMaintainenceService Ending");
        }

        public void ExecuteEmployeeConfiguration(EmployeeConfigurationType employeeConfigurationType)
        {
            var employee = _employeeConfigurationContractToModel.Convert(employeeConfigurationType);
            var action = employeeConfigurationType.Action;
            Logger.Debug(msg => msg(("EmployeeMaintenanceService called with action {0}"), Enum.GetName(typeof(ActionTypeCodes), action)));
            switch (action)
            {
                case ActionTypeCodes.AddOrUpdate:
                    AddOrUpdate(employee);
                    break;
                case ActionTypeCodes.Delete:
                    Delete(employee);
                    break;
                default:
                    AddOrUpdate(employee);
                    break;
            }
        }

        public void AddOrUpdate(IEmployeeConfiguration employeeConfiguration)
        {
            ValidateInputForAddUpdate(employeeConfiguration);
            _employeeConfigurationDao.SaveOrUpdate(employeeConfiguration);
        }

        public void Delete(IEmployeeConfiguration employeeConfiguration)
        {
            employeeConfiguration = ValidateInputForDelete(employeeConfiguration);
            _employeeConfigurationDao.Delete(employeeConfiguration);
        }
        private void ValidateInputForAddUpdate(IEmployeeConfiguration employeeConfiguration)
        {
            if (string.IsNullOrWhiteSpace(employeeConfiguration.Name))
                throw new BusinessException("Could not save Employee item - missing name");
            if (string.IsNullOrWhiteSpace(employeeConfiguration.Email))
                throw new BusinessException("Could not save Employee item - missing email");
            if (string.IsNullOrWhiteSpace(employeeConfiguration.Designation))
                throw new BusinessException("Could not save Employee item - missing designation");
        }
        private IEmployeeConfiguration ValidateInputForDelete(IEmployeeConfiguration employeeConfiguration)
        {
            if (employeeConfiguration.Id <= 0)
                throw new BusinessException("Employee Configuration Id doesnot match. Please check Input");
            return _employeeConfigurationDao.GetEmployeeConfigurationById(employeeConfiguration.Id);
        }
    }
}
