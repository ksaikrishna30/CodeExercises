﻿using Common.Logging;
using NCR.IT.Contracts.Generated.BundleItem;
using NCR.IT.Contracts.Generated.EmployeeConfiguration;
using NCR.IT.Server.BundleItem.Convertors;
using NCR.IT.Server.BundleItem.Exceptions;
using NCR.IT.Server.BundleItem.Model;
using NCR.IT.Server.Common;
using NCR.IT.Server.Model.BundleItem;
using Retalix.StoreServices.Model.Infrastructure.Service;
using NCR.IT.Server.Model.RegistrationAttributes;
using NCR.IT.Server.BundleItem.Convertors.EmployeeConfiguration;
using System.Collections.Generic;
using System.Linq;
using NCR.IT.Server.Common.BusinessServices;

namespace NCR.IT.Server.BundleItem.BusinessServices.EmployeeConfiguration
{

    [RegisterService] 
    public class EmployeeConfigurationLookupService : BusinessServiceBase<EmployeeConfigurationLookupRequest, EmployeeConfigurationLookupResponse>
    {
        private static readonly ILog Logger = LogManager.GetLogger(typeof(EmployeeConfigurationLookupService));
        private IEmployeeConfiguration _employeeConfiguration;
        private readonly IEmployeeConfigurationDao _employeeConfigurationDao;
        private readonly IEmployeeConfigurationModelToContract _employeeConfigurationModelToContract;
        private EmployeeConfigurationType[] _employeeConfigurationType; 

        public EmployeeConfigurationLookupService(IEmployeeConfigurationDao employeeConfigurationDao, IEmployeeConfigurationModelToContract employeeConfigurationModelToContract)
        {
            _employeeConfigurationDao = employeeConfigurationDao;
            _employeeConfigurationModelToContract = employeeConfigurationModelToContract;
        }

        protected override void InternalExecute()
        {
            Logger.Debug("EmployeeConfigurationLookupService called");

            if (Request == null) return;

            if (Request.Id > 0)
            {
                var employeeConfiguration = _employeeConfigurationDao.GetEmployeeConfigurationById(Request.Id);
                var employeeConfigurationContract = _employeeConfigurationModelToContract.Convert(employeeConfiguration);
                _employeeConfigurationType = new EmployeeConfigurationType[1] { employeeConfigurationContract };
            }
            else
            {
                var employeeConfigurationAll = _employeeConfigurationDao.GetAll();
                _employeeConfigurationType = employeeConfigurationAll.Select(_employeeConfigurationModelToContract.Convert).ToArray();
            }

            Logger.Debug(string.Format("EmployeeConfigurationLookupService call ended"));
        }

        protected override IDocumentResponse BuildResponse(EmployeeConfigurationLookupResponse response)
        {
            response.EmployeeConfigurationType = _employeeConfigurationType;
            return new DocumentResponse(response);
        }
    }
}
