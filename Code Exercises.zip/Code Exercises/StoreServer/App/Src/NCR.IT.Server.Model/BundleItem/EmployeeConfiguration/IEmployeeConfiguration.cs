﻿using Retalix.StoreServices.Model.Infrastructure.DataMovement;

namespace NCR.IT.Server.Model.BundleItem
{
    public interface IEmployeeConfiguration //: IMovable, INamedObject
    {
        int Id { get; set; }
        string Name { get; set; }
        string Email { get; set; }
        string Designation { get; set; }
    }
}
