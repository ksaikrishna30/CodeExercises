﻿namespace NCR.IT.Server.Model.BundleItem
{
    /// <summary>
    /// An abstract factory that hadles the reation of  <see cref="IEmployeeConfiguration"/>.
    /// 
    /// </summary>
    public interface IEmployeeConfigurationFactory
    {
        IEmployeeConfiguration CreateEmployeeConfiguration(int Id = 0, string Name = "", string Email = "", string Designation = "");
    }                                 
}                                     
