﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NCR.IT.Contracts.Generated.EmployeeConfiguration;
using Retalix.Client.Common.DataModels;

namespace NCR.IT.Client.POS.BusinessObjects.DataModels
{
     public interface IEmployeeConfigurationDataModel:IDataModel
    {
        EmployeeConfigurationLookupResponse employeeConfigurationLookupResponse { get; set; }
    }
}
