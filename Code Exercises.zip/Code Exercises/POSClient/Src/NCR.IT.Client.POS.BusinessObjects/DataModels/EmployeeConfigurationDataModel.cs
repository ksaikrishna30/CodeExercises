﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using Retalix.Client.Common.DataModels;
using NCR.IT.Contracts.Generated.EmployeeConfiguration;

namespace NCR.IT.Client.POS.BusinessObjects.DataModels
{
    [Export(typeof(IDataModel))]

    public class EmployeeConfigurationDataModel : IEmployeeConfigurationDataModel
    {
        public EmployeeConfigurationLookupResponse employeeConfigurationLookupResponse { get; set; }

        public void Clear()
        {
            employeeConfigurationLookupResponse = null;
        }

    }
}
