﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using Retalix.Client.POS.BusinessObjects.ServiceAgents.Validations;
using NCR.IT.Contracts.Generated.EmployeeConfiguration;

namespace NCR.IT.Client.POS.BusinessObjects.ServiceAgents.Validators
{
    [Export(typeof(IEmployeeConfigurationLookupValidator))]
    public class EmployeeConfigurationLookupValidator : RetalixValidatorBase, IEmployeeConfigurationLookupValidator
    {
        public void Validate(EmployeeConfigurationLookupRequest request, EmployeeConfigurationLookupResponse response)
        {
            ValidateResponseError(response.Header);
        }
    }
}
