﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NCR.IT.Contracts.Generated.EmployeeConfiguration;

namespace NCR.IT.Client.POS.BusinessObjects.ServiceAgents.Validators
{
    public interface IEmployeeConfigurationLookupValidator
    {
        void Validate(EmployeeConfigurationLookupRequest request, EmployeeConfigurationLookupResponse response);
    }
}
