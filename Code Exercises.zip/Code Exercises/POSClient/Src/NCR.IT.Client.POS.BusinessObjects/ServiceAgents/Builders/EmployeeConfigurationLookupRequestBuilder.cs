﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using Retalix.Client.CommonServices.Utils;
using Retalix.Contracts.Generated.Arts.PosLogV6.Source;
using Retalix.Contracts.Generated.Common;
using NCR.IT.Contracts.Generated.EmployeeConfiguration;

namespace NCR.IT.Client.POS.BusinessObjects.ServiceAgents.Builders
{
    [Export(typeof(IEmployeeConfigurationLookupRequestBuilder))]

    public class EmployeeConfigurationLookupRequestBuilder : IEmployeeConfigurationLookupRequestBuilder
    {
        public EmployeeConfigurationLookupRequest BuildLookupRequest(int id)
        {
            var employeeConfigurationLookupRequest = new EmployeeConfigurationLookupRequest()
            {
                Header = new RetalixCommonHeaderType()
                {
                    MessageId = new RequestIDCommonData()
                    {
                        Value = MessageIdGenerator.GetId().ToString()
                    }
                },
                Id = id

            };
            return employeeConfigurationLookupRequest;
        }
    }
}
