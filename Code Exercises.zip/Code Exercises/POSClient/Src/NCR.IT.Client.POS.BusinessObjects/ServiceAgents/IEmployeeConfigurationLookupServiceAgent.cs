﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Retalix.Client.Common.ServiceAgents;
using NCR.IT.Contracts.Generated.EmployeeConfiguration;

namespace NCR.IT.Client.POS.BusinessObjects.ServiceAgents
{
    public interface IEmployeeConfigurationLookupServiceAgent : IServiceAgent
    {
        EmployeeConfigurationLookupResponse Execute(int id);
    }
}
