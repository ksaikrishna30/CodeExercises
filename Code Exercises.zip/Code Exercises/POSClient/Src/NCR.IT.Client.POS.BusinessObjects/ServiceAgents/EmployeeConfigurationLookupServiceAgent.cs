﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using Common.Logging;
using NCR.IT.Client.POS.BusinessObjects.ServiceAgents.Builders;
using NCR.IT.Client.POS.BusinessObjects.Services;
using NCR.IT.Client.POS.BusinessObjects.ServiceAgents.Validators;
using Retalix.Client.Common.Exceptions;
using Retalix.Client.Common.Log;
using Retalix.Client.Common.ServiceAgents;
using NCR.IT.Contracts.Generated.EmployeeConfiguration;

namespace NCR.IT.Client.POS.BusinessObjects.ServiceAgents
{
    [Export(typeof(IServiceAgent))]
    public class EmployeeConfigurationLookupServiceAgent : IEmployeeConfigurationLookupServiceAgent
    {
        [Import]
        private IEmployeeConfigurationLookupService _employeeConfigurationLookupService;

        [Import]
        private IEmployeeConfigurationLookupValidator _employeeConfigurationLookupValidator;

        [Import]
        private IEmployeeConfigurationLookupRequestBuilder _employeeConfigurationLookupRequestBuilder;


        public EmployeeConfigurationLookupResponse Execute(int id)
        {
            var employeeConfigurationLookupRequest = _employeeConfigurationLookupRequestBuilder.BuildLookupRequest(id);
            var employeeConfigurationLookupResponse = _employeeConfigurationLookupService.Execute(employeeConfigurationLookupRequest);
            _employeeConfigurationLookupValidator.Validate(employeeConfigurationLookupRequest, employeeConfigurationLookupResponse);
           // ClientLog.ClientBusinessFlows.Debug("Test Log {0}", new BusinessException());
            return employeeConfigurationLookupResponse;
        }
    }
}
