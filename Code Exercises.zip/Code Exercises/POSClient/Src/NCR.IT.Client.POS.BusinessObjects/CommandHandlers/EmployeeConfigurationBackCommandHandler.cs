﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using NCR.IT.Client.POS.BusinessObjects;
using Retalix.Client.POS.BusinessObjects.CommandHandlers;

namespace NCR.IT.Client.POS.BusinessObjects.CommandHandlers
{
    [Export(typeof(IEmployeeConfigurationBackCommandHandler))]

    public class EmployeeConfigurationBackCommandHandler : PosCommandHandlerBase, IEmployeeConfigurationBackCommandHandler
    {
        private const string EmployeeConfigurationBackOutcome = "EmployeeConfigurationBackOutcome";

        protected override string ExecuteLogic()
        {
            return EmployeeConfigurationBackOutcome;
        }

    }
}
