﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Retalix.Client.Common.Handlers;

namespace NCR.IT.Client.POS.BusinessObjects.CommandHandlers
{
    public interface IEmployeeConfigurationBackCommandHandler:ICommandHandler
    {
    }
}