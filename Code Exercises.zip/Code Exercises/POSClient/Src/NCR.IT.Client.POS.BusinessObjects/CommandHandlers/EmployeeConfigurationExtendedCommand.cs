﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using NCR.IT.Client.POS.BusinessObjects;
using Retalix.Client.Common.Handlers;
using Retalix.Client.POS.BusinessObjects.Factory;
using Retalix.Client.Presentation.Core.ViewModels;

namespace NCR.IT.Client.POS.BusinessObjects.CommandHandlers
{
    [Export(typeof(IExtendedCommand))]
    public class EmployeeConfigurationExtendedCommand : IExtendedCommand
    {
        private const string EmployeeConfigurationCommandName = "EmployeeConfiguration";

        [Import]
        private ICommandHandlerFactory _commandHandlerFactory;
        public string CommandName { get { return EmployeeConfigurationCommandName; } }

        public ICommandHandler GetCommandHandler(ViewModelBase viewModel)
        {
            var commandHandler = _commandHandlerFactory.Create<IEmployeeConfigurationLookupCommandHandler>();
            return commandHandler;
        }
    
    }
}
