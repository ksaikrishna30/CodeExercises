﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using NCR.IT.Contracts.Generated.EmployeeConfiguration;
using NCR.IT.Client.POS.BusinessObjects;
using NCR.IT.Client.POS.BusinessObjects.DataModels;
using NCR.IT.Client.POS.BusinessObjects.ServiceAgents;
using Retalix.Client.POS.BusinessObjects.CommandHandlers;

namespace NCR.IT.Client.POS.BusinessObjects.CommandHandlers
{
    [Export(typeof(IEmployeeConfigurationLookupCommandHandler))]

    public class EmployeeConfigurationLookupCommandHandler : PosCommandHandlerBase, IEmployeeConfigurationLookupCommandHandler
    {
        private int _employeeConfigurationId;
        private const string EmployeeConfigurationLookupOutcome = "EmployeeConfigurationLookupOutcome";

        public void Init(int employeeConfigurationId)
        {
            _employeeConfigurationId = employeeConfigurationId;
        }

        protected override string ExecuteLogic()
        {
            var employeeConfigurationLookupResponse = ExecuteEmployeeConfigurationLookupServiceAgent();
            SetupEmployeeConfigurationDataModel(employeeConfigurationLookupResponse);
            return EmployeeConfigurationLookupOutcome;
        }

        private void SetupEmployeeConfigurationDataModel(EmployeeConfigurationLookupResponse employeeConfigurationLookupResponse)
        {
            var employeeConfigurationDataModel = GetDataModel<IEmployeeConfigurationDataModel>();
            employeeConfigurationDataModel.employeeConfigurationLookupResponse = employeeConfigurationLookupResponse;
        }

        private EmployeeConfigurationLookupResponse ExecuteEmployeeConfigurationLookupServiceAgent()
        {
            var employeeConfigurationLookupServiceAgent = GetServiceAgent<IEmployeeConfigurationLookupServiceAgent>();
            return employeeConfigurationLookupServiceAgent.Execute(_employeeConfigurationId);
        }
    }
}
