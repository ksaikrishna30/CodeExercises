﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NCR.IT.Contracts.Generated.EmployeeConfiguration;

namespace NCR.IT.Client.POS.BusinessObjects.Services
{
    public interface IEmployeeConfigurationLookupService
    {
        EmployeeConfigurationLookupResponse Execute(EmployeeConfigurationLookupRequest request);
    }
}
