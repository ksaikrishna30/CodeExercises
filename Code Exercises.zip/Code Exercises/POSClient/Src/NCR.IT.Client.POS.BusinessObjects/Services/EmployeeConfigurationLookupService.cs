﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using Retalix.Client.Net;
using NCR.IT.Contracts.Generated.EmployeeConfiguration;

namespace NCR.IT.Client.POS.BusinessObjects.Services
{
    [Export(typeof(IEmployeeConfigurationLookupService))]
    public class EmployeeConfigurationLookupService : ServiceBase, IEmployeeConfigurationLookupService
    {
        private const string ServiceName = "EmployeeConfigurationLookup";
        public EmployeeConfigurationLookupResponse Execute(EmployeeConfigurationLookupRequest request)
        {
            return Execute<EmployeeConfigurationLookupRequest, EmployeeConfigurationLookupResponse>(request, ServiceName);
        }
    }
}
