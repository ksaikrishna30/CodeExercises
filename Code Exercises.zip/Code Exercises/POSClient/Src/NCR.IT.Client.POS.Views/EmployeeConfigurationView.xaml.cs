﻿using System.Windows.Controls;

namespace NCR.IT.Client.POS.Views
{
    /// <summary>
    /// Interaction logic for EmployeeConfigurationView.xaml
    /// </summary>
    public partial class EmployeeConfigurationView : UserControl
    {
        public EmployeeConfigurationView()
        {
            InitializeComponent();
        }
    }
}
