﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Retalix.Client.POS.Presentation.ViewModels.ViewModels;
using Retalix.Client.Presentation.Core.Command;
using NCR.IT.Client.POS.BusinessObjects.DataModels;
using NCR.IT.Contracts.Generated.EmployeeConfiguration;
using System.Windows.Input;
using NCR.IT.Client.POS.BusinessObjects.CommandHandlers;

namespace NCR.IT.Client.POS.ViewsModels
{
    public class EmployeeConfigurationViewModel : PosViewModelBase
    {
        private IEmployeeConfigurationDataModel _employeeConfigurationDataModel;
        public ICommand BackCommand { get; private set; }

        private List<EmployeeConfigurationType> _employeeConfigurationElement;
        public List<EmployeeConfigurationType> employeeConfigurationElement
        {
            get { return _employeeConfigurationElement; }
            set { _employeeConfigurationElement = value; }
        }

        public EmployeeConfigurationViewModel()
        {
            Init();
            InitCommands();
        }

        private void Init()
        {
            _employeeConfigurationDataModel = _dataModelProvider.GetDataModel<IEmployeeConfigurationDataModel>();
            var employeeConfigurationList = new List<EmployeeConfigurationType>();
            var employeeConfigurationObj = _employeeConfigurationDataModel.employeeConfigurationLookupResponse.EmployeeConfigurationType;
            employeeConfigurationList.AddRange(employeeConfigurationObj);
            employeeConfigurationElement = employeeConfigurationList;
        }


        private void InitCommands()
        {
            BackCommand = new CommandAction<object>(ExecuteBackCommand, x => true);
        }

        protected virtual void ExecuteBackCommand(object obj)
        {

            ExecuteBackCommandHandler();
        }

        protected virtual void ExecuteBackCommandHandler()
        {
            var command = CommandHandlerFactory.Create<IEmployeeConfigurationBackCommandHandler>();
            ExecuteCommandHandlerAndStartFlow(command);
        }
    }
}
