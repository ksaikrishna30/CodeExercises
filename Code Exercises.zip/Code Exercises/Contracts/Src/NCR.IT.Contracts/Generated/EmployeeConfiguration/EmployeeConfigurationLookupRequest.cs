namespace NCR.IT.Contracts.Generated.EmployeeConfiguration
{
    using Retalix.Contracts.Generated.Common;
    using Retalix.Contracts.Generated.Arts.PosLogV6.Source;
    using NCR.IT.Contracts.Generated.Common;
    
    
    [System.CodeDom.Compiler.GeneratedCodeAttribute("BatchContractGenerator.Console", "14.100.999")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.Retalix.com/Extensions")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace="http://www.Retalix.com/Extensions", IsNullable=false)]
    public partial class EmployeeConfigurationLookupRequest : ServiceRequestBaseType
    {
        
        private int idField;
        
        private bool IdFieldSpecified;
        
        public int Id
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
                this.IdSpecified = true;
            }
        }
        
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public virtual bool IdSpecified
        {
            get
            {
                return this.IdFieldSpecified;
            }
            set
            {
                this.IdFieldSpecified = value;
            }
        }
    }
}
