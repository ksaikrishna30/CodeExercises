namespace NCR.IT.Contracts.Generated.EmployeeConfiguration
{
    using Retalix.Contracts.Generated.Common;
    using Retalix.Contracts.Generated.Arts.PosLogV6.Source;
    using NCR.IT.Contracts.Generated.Common;
    
    
    [System.CodeDom.Compiler.GeneratedCodeAttribute("BatchContractGenerator.Console", "14.100.999")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.Retalix.com/Extensions")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace="http://www.Retalix.com/Extensions", IsNullable=false)]
    public partial class EmployeeConfigurationLookupResponse : ServiceResponseBaseType
    {
        
        private EmployeeConfigurationType[] employeeConfigurationTypeField;
        
        [System.Xml.Serialization.XmlElementAttribute("EmployeeConfigurationType")]
        public EmployeeConfigurationType[] EmployeeConfigurationType
        {
            get
            {
                return this.employeeConfigurationTypeField;
            }
            set
            {
                this.employeeConfigurationTypeField = value;
            }
        }
    }
}
